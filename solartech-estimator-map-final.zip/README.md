
# SolarTech Estimator with Map (GitHub Pages Ready)

Features:
- Satellite map display
- Roof area drawing
- Auto-calculated area in estimate table

## Deploy Instructions
1. Create GitHub repo (e.g. solartech-estimator)
2. Upload `index.html` and `logo.jpg`
3. Go to Settings > Pages
4. Set Source = `main` and root folder `/`
5. Done ✅
